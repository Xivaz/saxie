prompt instalando versão 4.2.6 do APEX...

spool apexinstall.log;

@@apex_epg_config.sql C:\oraclexe\app\oracle\product\11.2.0\server\apex\
@@apxchpwd Kr4!thos

spool off;
disconnect;


exit;
